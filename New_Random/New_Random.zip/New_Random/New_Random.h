#ifndef New_Random_H
#define New_Random_H

#include<Arduino.h>

bool InArray(int v,int arr[],int arrsize){
  for(int i = 0;i<arrsize;i++){
    if(arr[i]==v)return true;
  }
  return false;
}

int New_Random(int from,int to,int except[],int arraysize){
  int random_list[from-to+1-arraysize];
  int count = 0;
  for(int i = from;i<=to;i++){
    if(!InArray(i,except,arraysize)){
      random_list[count]=i;
      count++;
    } 
  }
  int rnd = random(0,to-from+1-arraysize);
  return random_list[rnd];
}

#endif